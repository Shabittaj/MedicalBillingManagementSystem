/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package project;
import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author admin 1
 */
public class connectionprovider {
    public static Connection getCon()
    {
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mbms","root","Shabittaj_786");
            return con;
        } catch (Exception e) 
        {
            return null;
        } 
        
    }
    
}
